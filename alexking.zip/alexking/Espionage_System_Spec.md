# BẢNG THIẾT KẾ CHI TIẾT: HỆ THỐNG MẬT THÁM & TÌNH BÁO TÁC CHIẾN (ESPIONAGE OVERHAUL)

---

## 👁️ I. TỔNG QUAN Ý TƯỞNG & VAI TRÒ DÀNH CHO CÁC QUỐC GIA NHỎ
Hệ thống Mật thám mới được thiết kế để biến các **Nền văn minh nhỏ hoặc tụt hậu** thành những "Đế chế Bóng tối" (Shadow Empires). Không cần quân đội hùng hậu hay lãnh thổ bao la, các nước nhỏ có thể giăng mạng lưới Mật thám sương mù để:
- **Kìm hãm đà phát triển**: Trộm sạch công nghệ, làm đình trệ nhà máy, triệt hạ nguồn thu Vàng/Tài nguyên của đối thủ.
- **Ám sát & Tiêu sinh lực**: Thủ tiêu Vĩ nhân (Great Persons) và thủ tiêu quân lính đối phương ngay trong lòng thành phố.
- **Thao túng & Cân bằng thế trận**: Sống bám trên thành quả của các siêu cường, biến đối thủ thành "ngân hàng công nghệ".

---

## 🎖️ II. PHÂN CẤP MẬT THÁM 5 CẤP BẬC (5-TIER SPY SYSTEM)

| Cấp bậc | Tên gọi (Title) | Tốc độ công tác | Số tác vụ đồng thời | Cơ chế Ăn cắp Công nghệ |
| :--- | :--- | :--- | :--- | :--- |
| **Cấp 1** | **Recruit (Tân Binh)** | Tiêu chuẩn (100%) | 1 Tác vụ | Nhận điểm Science tích lũy (Bonus Progress) |
| **Cấp 2** | **Agent (Thám Báo)** | +25% Nhanh | 1 Tác vụ | Nhận điểm Science tích lũy (Bonus Progress) |
| **Cấp 3** | **Special Agent (Điệp Viên)** | +50% Nhanh | 1 Tác vụ | Nhận điểm Science tích lũy (Bonus Progress) |
| **Cấp 4** | **Master Spy (Bậc Thầy Tình Báo)** | +85% Nhanh | **2 Tác vụ đồng thời** *(Việc 2 -30% hiệu quả)* | **LẤY LUÔN CÔNG NGHỆ** (Instant Tech Completion) |
| **Cấp 5** | **Shadow Master (Điệp Vương Bóng Tối)** | +120% Nhanh | **3 Tác vụ đồng thời** *(Việc 2 -25%, Việc 3 -50%)* | **LẤY LUÔN CÔNG NGHỆ** (Instant Tech Completion) |

---

## 📜 III. CƠ CHẾ ĂN CẮP CÔNG NGHỆ CHUYÊN SÂU (TECH THEFT MECHANICS)

1. **Điều kiện tiên quyết (Prerequisite Building)**:
   - Mật thám **chỉ có thể ăn cắp được một Công nghệ** nếu thành phố mục tiêu **đã xây dựng công trình khoa học tương ứng** của công nghệ đó (VD: Muốn trộm *Scientific Method* thì thành phố đó phải có *University*, muốn trộm *Atomic Fission* thì phải có *Research Lab*).
2. **Cơ chế Tiết lộ Thông tin ở Mốc 10% (Early Tech Target Reveal)**:
   - Ngay khi quá trình trộm đạt **10% tiến độ**, hệ thống sẽ báo cho người chơi biết chính xác Mật thám đang nhắm vào Công nghệ nào. Người chơi có quyền tiếp tục hoặc hủy bỏ để chuyển mục tiêu.
3. **Phân hóa kết quả theo Cấp bậc Mật thám**:
   - **Cấp 1 đến Cấp 3**: Khi hoàn thành lượt trộm, Mật thám sẽ cộng một lượng **Điểm Khoa học cực lớn (Science Points)** thẳng vào cây công nghệ đang nghiên cứu dở của bạn.
   - **Cấp 4 đến Cấp 5**: Lấy **HOÀN TOÀN CÔNG NGHỆ** đó ngay lập tức, bỏ qua mọi chi phí điểm Science và hệ số phạt Kỷ nguyên!

---

## 🕸️ IV. MẠNG LƯỚI TÌNH BÁO LIÊN KẾT & DÂY NỐI BẢN ĐỒ (SPY NETWORK & VISUAL LINKS)

1. **Liên kết Mạng lưới (Network Formation)**:
   - Khi các Mật thám **Cấp 3 trở lên** cắm ở các thành phố lân cận hoặc tiếp giáp nhau, chúng sẽ tự động kích hoạt **"Mạng lưới Tình báo Liên kết" (Shadow Web)**.
2. **Biểu tượng Đồ họa (Visual Colored Lines)**:
   - Mạng lưới hiển thị bằng các **sợi dây nối mỏng có màu trùng với màu cờ Quốc gia** nối giữa các thành phố bị cài gián điệp.
3. **Hiệu ứng Mạng lưới (Network Buffs)**:
   - Tăng **+20% tốc độ thực thi mọi tác vụ** cho tất cả Mật thám nằm trong mạng lưới.
   - Tăng tỉ lệ thành công của các phi vụ ám sát và phá hoại tài nguyên.
4. **Cơ chế Dồn Mật thám (City Stacking - Tối đa 3 Mật thám/Thành phố)**:
   - Một thành phố có thể dồn đến **3 Mật thám** cùng lúc để cộng dồn hiệu ứng phá hoại lên mức tối đa.
   - **Rủi ro**: Khi Phản gián địch phát hiện, **1 Mật thám ngẫu nhiên sẽ bị tiêu diệt**, trong đó **Mật thám cấp thấp hơn sẽ có tỉ lệ bị bắt/chết cao hơn nhiều**.

---

## 🕵️‍♂️ V. BẢO MẬT SƯƠNG MÙ & HỒ SƠ TÀN PHÁ (STEALTH & DAMAGE DOSSIER)

1. **Bảo mật tuyệt đối trước khi bị lộ**:
   - Mọi hành vi do thám, trộm cắp, phá hoại đều diễn ra **hoàn toàn âm thầm**. Không có bất kỳ thông báo hay cảnh báo nào xuất hiện cho nạn nhân trừ khi Mật thám phản gián của họ phát hiện ra.
2. **Phản gián & Mức độ Bắt bớ theo Cấp bậc**:
   - **Phản gián Cấp thấp (Cấp 1 - 2)**: Tiêu diệt Mật thám xâm nhập thông thường, chỉ báo "Đã tiêu diệt gián điệp vô danh".
   - **Phản gián Cấp cao (Cấp 3 - 5)**:
     - Bắt sống / Tiêu diệt gián điệp địch.
     - **Lộ diện Quốc gia chủ mưu**: Báo chính xác gián điệp thuộc nước nào gửi tới.
     - **Bản Hồ sơ Tàn phá (Sabotage Damage Dossier)**: Liệt kê chi tiết toàn bộ các vụ thủ tiêu Vĩ nhân, ám sát quân lính và lượng Vàng/Công nghệ đã bị nước đó âm thầm rút ruột trong quá khứ!
3. **Phát hiện Mạng lưới Mật thám**:
   - Chỉ Mật thám Phản gián **Cấp 5 (Shadow Master)** mới có khả năng quét và phát hiện đường dây kết nối. Nếu mạng lưới quá lớn, Mật thám chỉ có thể làm lộ diện **1 phân nhánh của mạng lưới** chứ không lộ toàn bộ.

---

## 🎯 VI. CÁC TÁC VỤ MẬT THÁM CÓ THỂ CHỌN (CITY OPERATIONS)

Khi phái Mật thám vào một thành phố mục tiêu, người chơi được lựa chọn các Nông trình tác nghiệp:
1. **Thủ tiêu Vĩ nhân (Assassinate Great Person)**: Âm thầm tiêu diệt Vĩ nhân đang đứng trong thành phố đó.
2. **Thủ tiêu Quân lính (Assassinate Garrison Unit)**: Ám sát quân đồn trú hoặc làm giảm 50% HP quân đồn trú.
3. **Âm thầm Rút ruột Tài nguyên & Ngân khố (Resource & Gold Drain)**: Rút 15% lượng Vàng và vô hiệu hóa tài nguyên chiến lược của thành phố đó.
4. **Vô hiệu hóa Phòng thủ (Disable City Defense)**: Giảm 50% Lực bắn phòng thủ của thành phố khi quân ta áp sát công thành.
5. **Đánh cắp Công nghệ (Steal Technology)**: Thực hiện quy trình trộm công nghệ theo cấp bậc.
